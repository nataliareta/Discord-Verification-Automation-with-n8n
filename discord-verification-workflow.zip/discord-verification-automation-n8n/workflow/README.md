Place your sanitized n8n workflow export here.

Recommended filename:
discord-verification-workflow.json

Before committing, remove or replace:
- Discord Bot Token
- Server ID
- Role ID
- Channel ID
- Google Sheet ID
- OAuth secrets
- participant data
