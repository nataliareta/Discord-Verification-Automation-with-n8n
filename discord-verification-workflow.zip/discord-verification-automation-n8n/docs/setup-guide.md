# Setup Guide

This repository focuses on the project overview and sanitized workflow.

For a full setup, configure:

1. Google Form and Google Sheets
2. Google Cloud OAuth 2.0
3. Discord application and bot
4. Discord role hierarchy and channel permissions
5. n8n Google Sheets credentials
6. Discord API HTTP Request nodes
7. Verification logging using `Append or Update Row`
8. Duplicate protection and retry handling

> Do not place production tokens or participant data in this repository.
