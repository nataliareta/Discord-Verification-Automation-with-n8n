Add your sanitized n8n workflow screenshot here as `workflow-overview.png`.
